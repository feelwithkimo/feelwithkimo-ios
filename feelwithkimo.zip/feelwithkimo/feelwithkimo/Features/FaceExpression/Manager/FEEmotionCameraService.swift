//
//  FEEmotionCameraService.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 05/11/25.
//

import AVFoundation
import UIKit
import VideoToolbox

final class FEEmotionCameraService: NSObject {
    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var isConfigured = false

    var previewLayer: AVCaptureVideoPreviewLayer?
    var frameHandler: ((CGImage) -> Void)?

    func start() {
        print("🎥 Camera authorization status: \(AVCaptureDevice.authorizationStatus(for: .video).rawValue)")
        
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupPreviewLayer()
            configureSession()
            startSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                print("🎥 Camera access granted: \(granted)")
                if granted {
                    DispatchQueue.main.async {
                        self?.setupPreviewLayer()
                    }
                    self?.configureSession()
                    self?.startSession()
                }
            }
        default:
            print("❌ Camera access denied")
            break
        }
    }

    func stop() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.session.stopRunning()
        }
    }
    
    private func setupPreviewLayer() {
        print("🎥 Setting up preview layer...")
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        previewLayer = layer
        print("✅ Preview layer created and assigned")
    }

    private func configureSession() {
        print("🎥 Configuring camera session...")
        guard !isConfigured, session.inputs.isEmpty else {
            print("⚠️ Session already configured or has inputs")
            return
        }
        
        session.beginConfiguration()
        
        session.sessionPreset = .high

        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else {
            session.commitConfiguration()
            print("❌ Failed to configure camera input")
            return
        }
        session.addInput(input)
        print("✅ Camera input added")

        let queue = DispatchQueue(label: "fe.emotion.camera")
        videoOutput.setSampleBufferDelegate(self, queue: queue)
        videoOutput.alwaysDiscardsLateVideoFrames = true

        guard session.canAddOutput(videoOutput) else {
            session.commitConfiguration()
            print("❌ Failed to add video output")
            return
        }
        session.addOutput(videoOutput)
        print("✅ Video output added")
        
        // FIXED: Set orientation to 180 degrees (upside down correction)
        if let connection = videoOutput.connection(with: .video) {
            if #available(iOS 17.0, *) {
                connection.videoRotationAngle = 180 // Rotate 180 degrees to fix upside down
            } else {
                connection.videoOrientation = .landscapeLeft // Use landscapeLeft for iOS 16 and below
            }
            print("✅ Video orientation set to 180 degrees (landscape)")
        }

        session.commitConfiguration()
        print("✅ Session configuration committed")
        
        isConfigured = true
    }
    
    private func startSession() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.session.startRunning()
            print("✅ Session started running")
            
            // Set preview layer orientation after session starts
            DispatchQueue.main.async {
                if let layer = self?.previewLayer, let connection = layer.connection {
                    if #available(iOS 17.0, *) {
                        if connection.isVideoRotationAngleSupported(180) {
                            connection.videoRotationAngle = 180
                            print("✅ Preview layer orientation set to 180°")
                        }
                    } else {
                        if connection.isVideoOrientationSupported {
                            connection.videoOrientation = .landscapeLeft
                            print("✅ Preview layer orientation set to landscapeLeft")
                        }
                    }
                }
            }
        }
    }
}

extension FEEmotionCameraService: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            print("⚠️ Failed to get pixel buffer")
            return
        }
        
        var cgImage: CGImage?
        let options: [String: Any]? = nil
        let status = VTCreateCGImageFromCVPixelBuffer(pixelBuffer, options: options as CFDictionary?, imageOut: &cgImage)
        
        if status != noErr {
            print("❌ VTCreateCGImageFromCVPixelBuffer failed with status: \(status)")
            return
        }
        
        if let cgImage {
            // Log first few frames
            let width = cgImage.width
            let height = cgImage.height
            if width > 0 && height > 0 {
                frameHandler?(cgImage)
            }
        } else {
            print("❌ cgImage is nil after conversion")
        }
    }
}
