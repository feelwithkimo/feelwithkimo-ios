//
//  FEEmotionFaceImageTool.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 05/11/25.
//

import Foundation
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins

final class FEEmotionFaceImageTool {
    private let context = CIContext()

    /// Detect faces and return face observations
    func detectFaces(in cgImage: CGImage) throws -> [VNFaceObservation] {
        print("🔍 Starting face detection on image size: \(cgImage.width)x\(cgImage.height)")
        
        // Use VNDetectFaceLandmarksRequest instead for better detection
        let req = VNDetectFaceLandmarksRequest()
        
        // Try different orientations to account for camera rotation
        let orientations: [CGImagePropertyOrientation] = [.up, .right, .left, .down]
        
        for orientation in orientations {
            let handler = VNImageRequestHandler(cgImage: cgImage, orientation: orientation)
            do {
                try handler.perform([req])
                
                if let results = req.results as? [VNFaceObservation], !results.isEmpty {
                    print("✅ Found \(results.count) face(s) with orientation: \(orientation)")
                    for (i, face) in results.enumerated() {
                        print("   Face \(i): bbox = \(face.boundingBox), confidence = \(face.confidence)")
                    }
                    return results
                }
            } catch {
                print("⚠️ Face detection failed with orientation \(orientation): \(error)")
            }
        }
        
        print("⚠️ No faces detected with any orientation")
        return []
    }

    /// Crop a face using Vision bbox (normalized, origin lower-left)
    func cropFace(from cgImage: CGImage, boundingBox: CGRect) -> CGImage? {
        let w = CGFloat(cgImage.width), h = CGFloat(cgImage.height)
        
        // Add padding around the face (10% on each side)
        let padding: CGFloat = 0.1
        let paddedBox = CGRect(
            x: max(0, boundingBox.origin.x - padding),
            y: max(0, boundingBox.origin.y - padding),
            width: min(1.0, boundingBox.width + 2 * padding),
            height: min(1.0, boundingBox.height + 2 * padding)
        )
        
        let x = paddedBox.origin.x * w
        let y = (1.0 - paddedBox.origin.y - paddedBox.height) * h
        let rect = CGRect(x: x, y: y, width: paddedBox.width * w, height: paddedBox.height * h).integral
        
        print("🔲 Cropping face from \(rect)")
        
        guard rect.width > 0, rect.height > 0,
              rect.minX >= 0, rect.minY >= 0,
              rect.maxX <= CGFloat(cgImage.width),
              rect.maxY <= CGFloat(cgImage.height) else {
            print("❌ Invalid crop rect: \(rect)")
            return nil
        }
        
        return cgImage.cropping(to: rect)
    }

    /// Resize a CGImage to target size using Core Image
    func resize(_ cgImage: CGImage, to size: CGSize) -> CGImage? {
        let ciImage = CIImage(cgImage: cgImage)
        let sx = size.width / CGFloat(cgImage.width)
        let sy = size.height / CGFloat(cgImage.height)
        let scaled = ciImage.transformed(by: CGAffineTransform(scaleX: sx, y: sy))
        
        guard let resized = context.createCGImage(scaled, from: CGRect(origin: .zero, size: size)) else {
            print("❌ Failed to resize image to \(size)")
            return nil
        }
        
        print("✅ Resized image to \(size)")
        return resized
    }
}
