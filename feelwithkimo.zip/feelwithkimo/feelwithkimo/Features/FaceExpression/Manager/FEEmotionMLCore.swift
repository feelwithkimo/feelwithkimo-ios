//
//  FEEmotionMLCore.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 05/11/25.
//

import Foundation
import Vision
import CoreML
import CoreGraphics
import CoreVideo

@MainActor
final class FEEmotionMLCore {
    private let faceTool = FEEmotionFaceImageTool()
    private var mlModel: FacialExpressionModel?
    private let inputSize = CGSize(width: 48, height: 48) // Your model expects 48x48
    
    // Emotion labels in the order your model outputs them
    // IMPORTANT: Adjust this order based on how your model was trained!
    private let emotionLabels: [FEEmotion] = [
        .angry,      // index 0
        .disgust,    // index 1
        .fear,       // index 2
        .happy,      // index 3
        .sad,        // index 4
        .surprise,   // index 5
        .neutral     // index 6
    ]

    /// Build Core ML model
    private func makeModel() throws -> FacialExpressionModel {
        print("🤖 Loading ML model...")
        let config = MLModelConfiguration()
        let model = try FacialExpressionModel(configuration: config)
        print("✅ ML model loaded successfully")
        return model
    }

    /// Analyze one frame → per-face FEEmotionAnalysis list
    func analyze(_ cgImage: CGImage) throws -> [FEEmotionAnalysis] {
        if mlModel == nil {
            mlModel = try makeModel()
        }
        guard let mlModel else {
            print("❌ ML Model is nil")
            return []
        }

        // 1) detect faces
        let faces = try faceTool.detectFaces(in: cgImage)
        if faces.isEmpty {
            print("⚠️ No faces detected in frame")
            return []
        }
        print("👤 Detected \(faces.count) face(s)")

        var analyses: [FEEmotionAnalysis] = []
        for (index, obs) in faces.enumerated() {
            // 2) crop & resize to 48x48
            guard let cropped = faceTool.cropFace(from: cgImage, boundingBox: obs.boundingBox) else {
                print("❌ Failed to crop face \(index)")
                continue
            }
            
            guard let resized = faceTool.resize(cropped, to: inputSize) else {
                print("❌ Failed to resize face \(index)")
                continue
            }
            
            // 3) Convert to grayscale CVPixelBuffer
            guard let pixelBuffer = resized.toGrayscalePixelBuffer() else {
                print("❌ Failed to convert to pixel buffer")
                continue
            }
            
            print("✅ Face \(index) prepared: 48x48 grayscale")

            // 4) Run prediction
            do {
                let output = try mlModel.prediction(conv2d_input: pixelBuffer)
                
                // 5) Extract probabilities from MultiArray
                let multiArray = output.Identity
                let probabilities = extractProbabilities(from: multiArray)
                
                print("📊 Face \(index) predictions:")
                
                // 6) Map to FEEmotion scores (0..100)
                var scores: [FEEmotion: Double] = [:]
                for (idx, emotion) in emotionLabels.enumerated() {
                    if idx < probabilities.count {
                        let score = probabilities[idx] * 100.0
                        scores[emotion] = score
                        print("   \(emotion.displayName): \(String(format: "%.1f", score))%")
                    }
                }
                
                // Fill missing emotions with 0
                for e in FEEmotion.allCases where scores[e] == nil {
                    scores[e] = 0
                }

                let dominant = scores.dominantEmotion ?? .neutral
                print("✅ Dominant emotion for face \(index): \(dominant.rawValue)")
                
                analyses.append(FEEmotionAnalysis(region: obs.boundingBox, scores: scores, dominant: dominant))
                
            } catch {
                print("❌ Prediction failed for face \(index): \(error)")
                continue
            }
        }
        
        return analyses
    }
    
    /// Extract probabilities from MLMultiArray
    private func extractProbabilities(from multiArray: MLMultiArray) -> [Double] {
        var probabilities: [Double] = []
        let count = multiArray.count
        
        for i in 0..<count {
            let value = multiArray[i].doubleValue
            probabilities.append(value)
        }
        
        return probabilities
    }
}

// MARK: - CGImage to Grayscale CVPixelBuffer
extension CGImage {
    func toGrayscalePixelBuffer() -> CVPixelBuffer? {
        let width = self.width
        let height = self.height
        
        let attrs = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_OneComponent8
        ] as CFDictionary
        
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_OneComponent8,
            attrs,
            &pixelBuffer
        )
        
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        
        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceGray(),
            bitmapInfo: CGImageAlphaInfo.none.rawValue
        )
        
        guard let ctx = context else { return nil }
        
        ctx.draw(self, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        return buffer
    }
}
