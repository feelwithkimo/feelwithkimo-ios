//
//  FaceExpressionView.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import SwiftUI
import AVFoundation

/// Main view for face expression detection feature
/// Detects and tracks angry facial expressions with progress feedback
struct FaceExpressionView: View {
    @StateObject private var viewModel = FaceExpressionViewModel()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            // Background
            Color(red: 0.98, green: 0.96, blue: 0.98)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Top Navigation Bar
                topNavigationBar
                
                // Main Content
                HStack(alignment: .center, spacing: 100) {
                    leftSideContent
                    rightSideCameraView
                }
                
                Spacer()
            }
            .padding(.top, 50)
            .padding(.horizontal, 80)
            .padding(.bottom, 50)
            
            // Kimo Ask View - Floating mascot with dialogue
            KimoAskView(
                dialogueText: "Tahan ekspresi marah selama 4 detik untuk melanjutkan!",
                dialogueIcon: "Kimo",
                textDialogueLeft: "TextDialogueLeft",
                titleText: "Tiru Muka Marah",
                bodyText: "Posisikan wajahmu dan tiru ekspresi marah"
            )
        }
        .onAppear {
            print("👀 FaceExpressionView appeared")
            // Delay camera start to ensure view is rendered
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                print("🎬 Starting camera after view render...")
                viewModel.start()
            }
        }
        .onDisappear {
            print("👋 FaceExpressionView disappeared")
            viewModel.stop()
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - View Components
    
    private var topNavigationBar: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                KimoBackButton()
            }
            .frame(width: 55, height: 55)
            
            Spacer()
        }
        .padding(.bottom, 30)
    }
    
    private var leftSideContent: some View {
        VStack(alignment: .leading, spacing: 32) {
            Text("Tiru Muka\nMarah")
                .font(.system(size: 64, weight: .heavy, design: .rounded))
                .foregroundColor(Color(red: 0x5E/255, green: 0x55/255, blue: 0x73/255))
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
            
            Image("KimoAngry")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 300)
        }
    }
    
    private var rightSideCameraView: some View {
        ZStack {
            // Green Box Background with Animated Border
            RoundedRectangle(cornerRadius: 48)
                .fill(Color(red: 172/255, green: 236/255, blue: 199/255))
                .frame(width: 620, height: 620)
            
            // Animated Progress Border
            AnimatedProgressBorder(
                progress: viewModel.progress,
                isComplete: viewModel.isComplete
            )
            .frame(width: 620, height: 620)
            
            // Camera preview with overlays
            cameraPreviewContent
        }
    }
    
    private var cameraPreviewContent: some View {
        ZStack {
            // Camera preview or loading placeholder
            Group {
                if let layer = viewModel.previewLayer {
                    CameraPreviewView(layer: layer)
                        .clipShape(RoundedRectangle(cornerRadius: 36))
                        .onAppear {
                            print("📺 CameraPreviewView appeared with layer")
                        }
                } else {
                    loadingPlaceholder
                }
            }
            .frame(width: 550, height: 550)
            
            // Emotion Detection Overlay (shows "No face detected" when needed)
            EmotionDetectionOverlay(
                analyses: viewModel.analyses,
                isAngry: viewModel.isAngryAggregated
            )
            .frame(width: 550, height: 550)
        }
        .overlay(faceGuideStroke, alignment: .center)
        .overlay(instructionText, alignment: .bottom)
    }
    
    private var loadingPlaceholder: some View {
        RoundedRectangle(cornerRadius: 36)
            .fill(Color.black.opacity(0.3))
            .overlay(
                VStack(spacing: 12) {
                    ProgressView()
                        .scaleEffect(1.5)
                        .tint(.white)
                    Text("Loading camera...")
                        .font(.system(size: 14))
                        .foregroundColor(.white)
                }
            )
            .onAppear {
                print("⏳ Waiting for preview layer...")
            }
    }
    
    private var faceGuideStroke: some View {
        Image("FaceExpressionStrokeGuide")
            .resizable()
            .scaledToFit()
            .frame(width: 450, height: 450)
    }
    
    private var instructionText: some View {
        Text(viewModel.isComplete ? "Berhasil! 🎉" : "Ayo, posisikan wajahmu di dalam garis putus-putus ya!")
            .font(.system(size: 18, weight: .semibold))
            .foregroundColor(Color(red: 0x5E/255, green: 0x55/255, blue: 0x73/255))
            .padding(.horizontal, 24)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(viewModel.isComplete ? Color(red: 0xFF/255, green: 0xD7/255, blue: 0x00/255) : Color(red: 0xFA/255, green: 0xC0/255, blue: 0xD8/255))
                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)
            )
            .padding(.bottom, 30)
    }
}

// MARK: - Preview
#if DEBUG
struct FaceExpressionView_Previews: PreviewProvider {
    static var previews: some View {
        FaceExpressionView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
#endif
