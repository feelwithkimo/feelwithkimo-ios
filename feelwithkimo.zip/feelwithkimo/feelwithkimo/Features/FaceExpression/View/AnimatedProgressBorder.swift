//
//  AnimatedProgressBorder.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import SwiftUI

/// Animated border that progressively fills around a rounded rectangle
/// Progress goes clockwise: top -> right -> bottom -> left over 4 seconds
struct AnimatedProgressBorder: View {
    let progress: CGFloat // 0.0 to 4.0 (represents 0-4 seconds)
    let isComplete: Bool
    
    private let borderThickness: CGFloat = 70
    private let cornerRadius: CGFloat = 48
    
    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            let height = geo.size.height
            
            // Calculate progress for each side (0.0 to 1.0 per side)
            let topProgress = min(max(progress, 0), 1.0)
            let rightProgress = min(max(progress - 1.0, 0), 1.0)
            let bottomProgress = min(max(progress - 2.0, 0), 1.0)
            let leftProgress = min(max(progress - 3.0, 0), 1.0)
            
            let borderColor = isComplete ? Color.yellow : Color.red
            
            ZStack {
                // Top border (left to right)
                if topProgress > 0 {
                    Rectangle()
                        .fill(borderColor)
                        .frame(width: width * topProgress, height: borderThickness)
                        .position(x: (width * topProgress) / 2, y: borderThickness / 2)
                }
                
                // Right border (top to bottom)
                if rightProgress > 0 {
                    Rectangle()
                        .fill(borderColor)
                        .frame(width: borderThickness, height: height * rightProgress)
                        .position(x: width - borderThickness / 2, y: (height * rightProgress) / 2)
                }
                
                // Bottom border (right to left)
                if bottomProgress > 0 {
                    Rectangle()
                        .fill(borderColor)
                        .frame(width: width * bottomProgress, height: borderThickness)
                        .position(x: width - (width * bottomProgress) / 2, y: height - borderThickness / 2)
                }
                
                // Left border (bottom to top)
                if leftProgress > 0 {
                    Rectangle()
                        .fill(borderColor)
                        .frame(width: borderThickness, height: height * leftProgress)
                        .position(x: borderThickness / 2, y: height - (height * leftProgress) / 2)
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
        .allowsHitTesting(false)
        .animation(.linear(duration: 0.1), value: progress)
    }
}

#if DEBUG
struct AnimatedProgressBorder_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 48)
                .fill(Color.green.opacity(0.3))
                .frame(width: 620, height: 620)
            
            AnimatedProgressBorder(progress: 2.5, isComplete: false)
                .frame(width: 620, height: 620)
        }
        .previewLayout(.sizeThatFits)
        .padding()
    }
}
#endif
