//
//  EmotionDetectionOverlay.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import SwiftUI

/// Overlay view that shows face detection status
/// Only displays "No face detected" message when needed
struct EmotionDetectionOverlay: View {
    let analyses: [FEEmotionAnalysis]
    let isAngry: Bool
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Show "No face detected" message when no faces are found
                if analyses.isEmpty {
                    VStack {
                        Spacer()
                        
                        HStack(spacing: 8) {
                            Image(systemName: "face.dashed")
                                .font(.system(size: 16))
                            Text("No face detected")
                                .font(.system(size: 16, weight: .medium, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(
                            Capsule()
                                .fill(Color.orange.opacity(0.9))
                                .shadow(color: .black.opacity(0.15), radius: 6, x: 0, y: 3)
                        )
                        .padding(.bottom, 80)
                    }
                }
            }
        }
    }
}

#if DEBUG
struct EmotionDetectionOverlay_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.black
            
            EmotionDetectionOverlay(
                analyses: [],
                isAngry: false
            )
        }
        .previewLayout(.fixed(width: 550, height: 550))
    }
}
#endif
