//
//  CameraPreviewView.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import SwiftUI
import AVFoundation

/// UIViewRepresentable wrapper for AVCaptureVideoPreviewLayer
/// Displays the camera preview in SwiftUI
struct CameraPreviewView: UIViewRepresentable {
    let layer: AVCaptureVideoPreviewLayer
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .black
        layer.frame = view.bounds
        layer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(layer)
        print("📺 CameraPreviewView: UIView created")
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            layer.frame = uiView.bounds
        }
    }
}
