//
//  FaceExpressionViewModel.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 06/11/25.
//

import Foundation
import Combine
import AVFoundation

@MainActor
final class FaceExpressionViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var analyses: [FEEmotionAnalysis] = []
    @Published var fps: Double = 0
    @Published var previewLayer: AVCaptureVideoPreviewLayer?
    @Published var isAngryAggregated: Bool = false
    @Published var progress: CGFloat = 0.0 // 0.0 to 4.0 (4 seconds)
    @Published var isComplete: Bool = false
    
    // MARK: - Private Properties
    private let camera = FEEmotionCameraService()
    private let ml = FEEmotionMLCore()
    private let aggregator = FEEmotionAggregator()
    private let progressTracker = AngryProgressTracker()
    
    // Smoothing / throttling
    private var lastFrameTime: CFTimeInterval = CFAbsoluteTimeGetCurrent()
    private let throttle = DispatchSemaphore(value: 1)
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    init() {
        setupProgressTrackerBinding()
    }
    
    // MARK: - Public Methods
    func start() {
        print("🎬 Starting FaceExpressionViewModel...")
        
        setupCameraFrameHandler()
        camera.start()
        progressTracker.start()
        
        // Assign preview layer
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            guard let self = self else { return }
            self.previewLayer = self.camera.previewLayer
            print("🎬 Preview layer assigned in ViewModel: \(self.previewLayer != nil)")
        }
    }
    
    func stop() {
        print("🛑 Stopping camera and progress tracker...")
        aggregator.reset()
        progressTracker.stop()
        camera.stop()
        cancellables.removeAll()
    }
    
    // MARK: - Private Methods
    private func setupProgressTrackerBinding() {
        // Bind progress tracker updates to view model
        progressTracker.$progress
            .receive(on: DispatchQueue.main)
            .assign(to: &$progress)
        
        progressTracker.$isComplete
            .receive(on: DispatchQueue.main)
            .assign(to: &$isComplete)
    }
    
    private func setupCameraFrameHandler() {
        camera.frameHandler = { [weak self] cgImage in
            guard let self else { return }
            
            // Calculate FPS
            let now = CFAbsoluteTimeGetCurrent()
            let delta = now - self.lastFrameTime
            self.lastFrameTime = now
            Task { @MainActor in self.fps = 1.0 / max(delta, 1e-3) }
            
            // Throttle to ~8 FPS
            if self.throttle.wait(timeout: .now()) == .success {
                Task.detached(priority: .userInitiated) { [weak self] in
                    defer { self?.throttle.signal(); usleep(120_000) }
                    guard let self else { return }
                    do {
                        let out = try await self.runAnalyze(cgImage)
                        await MainActor.run {
                            self.processAnalysisResults(out)
                        }
                    } catch {
                        print("⚠️ Analysis error: \(error)")
                    }
                }
            }
        }
    }
    
    private func processAnalysisResults(_ results: [FEEmotionAnalysis]) {
        self.analyses = results
        
        if let firstFace = results.first {
            // Update aggregator with dominant emotion
            aggregator.addDetection(firstFace.dominant)
            
            // Get angry probability
            let angryProb = firstFace.scores[.angry] ?? 0.0
            
            // Determine if "Angry" based on aggregation rules
            isAngryAggregated = aggregator.isAngry(currentAngryProbability: angryProb)
            
            // Update progress tracker
            progressTracker.updateAngryState(isAngry: isAngryAggregated)
        } else {
            // No face detected - reset everything
            aggregator.reset()
            isAngryAggregated = false
            progressTracker.updateAngryState(isAngry: false)
        }
    }
    
    private func runAnalyze(_ image: CGImage) async throws -> [FEEmotionAnalysis] {
        try ml.analyze(image)
    }
}
