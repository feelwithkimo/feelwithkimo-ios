//
//  AngryProgressTracker.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import Foundation
import Combine
import SwiftUI

/// Tracks progress of angry emotion detection over time
/// Progress fills over 4 seconds of sustained angry detection
@MainActor
final class AngryProgressTracker: ObservableObject {
    // MARK: - Published Properties
    @Published var progress: CGFloat = 0.0 // 0.0 to 4.0 (4 seconds)
    @Published var isComplete: Bool = false
    
    // MARK: - Private Properties
    private var timer: Timer?
    private var lastAngryState: Bool = false
    private var notAngryStartTime: Date?
    
    // Configuration
    private let totalDuration: TimeInterval = 4.0 // 4 seconds total
    private let resetThreshold: TimeInterval = 0.5 // 0.5 seconds of not angry resets
    private let tickInterval: TimeInterval = 0.05 // Update every 50ms
    
    // MARK: - Public Methods
    func start() {
        print("⏱️ Starting AngryProgressTracker...")
        timer = Timer.scheduledTimer(withTimeInterval: tickInterval, repeats: true) { [weak self] _ in
            self?.tick()
        }
    }
    
    func stop() {
        print("⏱️ Stopping AngryProgressTracker...")
        timer?.invalidate()
        timer = nil
        reset()
    }
    
    func updateAngryState(isAngry: Bool) {
        if isAngry {
            // Reset the not-angry timer when angry is detected
            notAngryStartTime = nil
        } else {
            // Start tracking how long we've been not angry
            if notAngryStartTime == nil {
                notAngryStartTime = Date()
            }
        }
        lastAngryState = isAngry
    }
    
    func reset() {
        progress = 0.0
        isComplete = false
        lastAngryState = false
        notAngryStartTime = nil
        print("🔄 AngryProgressTracker reset")
    }
    
    // MARK: - Private Methods
    private func tick() {
        // Check if we need to reset progress
        if shouldResetProgress() {
            withAnimation(.easeOut(duration: 0.3)) {
                progress = 0.0
                isComplete = false
            }
            return
        }
        
        // Increment progress if angry and not yet complete
        if lastAngryState && !isComplete {
            incrementProgress()
        }
    }
    
    private func shouldResetProgress() -> Bool {
        guard let notAngryStart = notAngryStartTime else {
            return false
        }
        
        let notAngryDuration = Date().timeIntervalSince(notAngryStart)
        if notAngryDuration >= resetThreshold {
            print("🔄 Progress reset - not angry for \(String(format: "%.2f", notAngryDuration))s")
            return true
        }
        
        return false
    }
    
    private func incrementProgress() {
        let increment: CGFloat = tickInterval / totalDuration * 4.0 // Maps to 0-4 range
        progress = min(progress + increment, 4.0)
        
        // Check if complete
        if progress >= 4.0 && !isComplete {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                isComplete = true
            }
            print("✅ Angry expression held for 4 seconds! Progress complete.")
        }
    }
}
