//
//  FaceExpressionDebugView.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 07/11/25.
//

import SwiftUI
import AVFoundation

/// Debug view for face expression detection with detailed overlay information
/// Same UI as production but with debug overlays showing emotion data
struct FaceExpressionDebugView: View {
    @StateObject private var viewModel = FaceExpressionViewModel()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            // Background
            Color(red: 0.98, green: 0.96, blue: 0.98)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Top Navigation Bar
                topNavigationBar
                
                // Main Content
                HStack(alignment: .center, spacing: 100) {
                    leftSideContent
                    rightSideCameraView
                }
                
                Spacer()
            }
            .padding(.top, 50)
            .padding(.horizontal, 80)
            .padding(.bottom, 50)
        }
        .onAppear {
            print("👀 FaceExpressionDebugView appeared")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                print("🎬 Starting camera after view render...")
                viewModel.start()
            }
        }
        .onDisappear {
            print("👋 FaceExpressionDebugView disappeared")
            viewModel.stop()
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - View Components
    
    private var topNavigationBar: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                KimoBackButton()
            }
            .frame(width: 55, height: 55)
            
            Spacer()
            
            // Debug mode indicator
            HStack(spacing: 8) {
                Image(systemName: "ant.fill")
                    .font(.system(size: 16))
                Text("DEBUG MODE")
                    .font(.system(size: 14, weight: .bold, design: .monospaced))
            }
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                Capsule()
                    .fill(Color.orange)
            )
        }
        .padding(.bottom, 30)
    }
    
    private var leftSideContent: some View {
        VStack(alignment: .leading, spacing: 32) {
            Text("Tiru Muka\nMarah")
                .font(.system(size: 64, weight: .heavy, design: .rounded))
                .foregroundColor(Color(red: 0x5E/255, green: 0x55/255, blue: 0x73/255))
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
            
            Image("KimoAngry")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 300)
        }
    }
    
    private var rightSideCameraView: some View {
        ZStack {
            // Green Box Background with Animated Border
            RoundedRectangle(cornerRadius: 48)
                .fill(Color(red: 172/255, green: 236/255, blue: 199/255))
                .frame(width: 620, height: 620)
            
            // Animated Progress Border
            AnimatedProgressBorder(
                progress: viewModel.progress,
                isComplete: viewModel.isComplete
            )
            .frame(width: 620, height: 620)
            
            // Camera preview with DEBUG overlays
            cameraPreviewContent
        }
    }
    
    private var cameraPreviewContent: some View {
        ZStack {
            // Camera preview or loading placeholder
            Group {
                if let layer = viewModel.previewLayer {
                    CameraPreviewView(layer: layer)
                        .clipShape(RoundedRectangle(cornerRadius: 36))
                        .onAppear {
                            print("📺 CameraPreviewView appeared with layer")
                        }
                } else {
                    loadingPlaceholder
                }
            }
            .frame(width: 550, height: 550)
            
            // DEBUG: Detailed Emotion Detection Overlay
            EmotionDetectionDebugOverlay(
                analyses: viewModel.analyses,
                isAngry: viewModel.isAngryAggregated,
                fps: viewModel.fps
            )
            .frame(width: 550, height: 550)
        }
        .overlay(faceGuideStroke, alignment: .center)
        .overlay(instructionText, alignment: .bottom)
    }
    
    private var loadingPlaceholder: some View {
        RoundedRectangle(cornerRadius: 36)
            .fill(Color.black.opacity(0.3))
            .overlay(
                VStack(spacing: 12) {
                    ProgressView()
                        .scaleEffect(1.5)
                        .tint(.white)
                    Text("Loading camera...")
                        .font(.system(size: 14))
                        .foregroundColor(.white)
                }
            )
    }
    
    private var faceGuideStroke: some View {
        Image("FaceExpressionStrokeGuide")
            .resizable()
            .scaledToFit()
            .frame(width: 450, height: 450)
    }
    
    private var instructionText: some View {
        Text(viewModel.isComplete ? "Berhasil! 🎉" : "Ayo, posisikan wajahmu di dalam garis putus-putus ya!")
            .font(.system(size: 18, weight: .semibold))
            .foregroundColor(Color(red: 0x5E/255, green: 0x55/255, blue: 0x73/255))
            .padding(.horizontal, 24)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(viewModel.isComplete ? Color(red: 0xFF/255, green: 0xD7/255, blue: 0x00/255) : Color(red: 0xFA/255, green: 0xC0/255, blue: 0xD8/255))
                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)
            )
            .padding(.bottom, 30)
    }
}

// MARK: - Debug Overlay with Detailed Info
struct EmotionDetectionDebugOverlay: View {
    let analyses: [FEEmotionAnalysis]
    let isAngry: Bool
    let fps: Double
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                // No face detected message
                if analyses.isEmpty {
                    VStack {
                        Spacer()
                        
                        HStack(spacing: 8) {
                            Image(systemName: "face.dashed")
                                .font(.system(size: 16))
                            Text("No face detected")
                                .font(.system(size: 16, weight: .medium, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(
                            Capsule()
                                .fill(Color.orange.opacity(0.9))
                                .shadow(color: .black.opacity(0.15), radius: 6, x: 0, y: 3)
                        )
                        .padding(.bottom, 80)
                    }
                }
                
                // Draw bounding boxes and labels for detected faces
                ForEach(analyses) { analysis in
                    let rect = visionRectToSwiftUI(analysis.region, in: geo.size)
                    
                    // Bounding box
                    Rectangle()
                        .strokeBorder(isAngry ? Color.red : Color.green, lineWidth: 3)
                        .frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                        .animation(.easeInOut(duration: 0.2), value: isAngry)
                    
                    // Angry/Not Angry Label above face
                    Text(isAngry ? "😠 ANGRY" : "😊 Not Angry")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(
                            Capsule()
                                .fill(isAngry ? Color.red.opacity(0.95) : Color.green.opacity(0.95))
                        )
                        .position(x: rect.midX, y: rect.minY - 20)
                }
                
                // All emotion probabilities panel (top-left, fixed position)
                if let firstAnalysis = analyses.first {
                    VStack(alignment: .leading) {
                        fpsIndicator
                        emotionProbabilitiesPanel(for: firstAnalysis, at: CGRect.zero, in: geo.size)
                    }
                    .padding(12)
                }
            }
        }
    }
    
    private var fpsIndicator: some View {
        HStack(spacing: 8) {
            Image(systemName: "speedometer")
                .font(.system(size: 12))
            Text(String(format: "%.1f FPS", fps))
                .font(.system(size: 12, weight: .bold, design: .monospaced))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(
            Capsule()
                .fill(Color.black.opacity(0.7))
        )
    }
    
    private func emotionProbabilitiesPanel(for analysis: FEEmotionAnalysis, at rect: CGRect, in size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("Emotion Probabilities")
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .padding(.bottom, 2)
            
            ForEach(FEEmotion.allCases, id: \.self) { emotion in
                if let score = analysis.scores[emotion] {
                    HStack(spacing: 6) {
                        Text(emotion.displayName)
                            .font(.system(size: 11, weight: .medium, design: .rounded))
                            .foregroundColor(.white)
                            .frame(width: 70, alignment: .leading)
                        
                        // Progress bar
                        GeometryReader { barGeo in
                            ZStack(alignment: .leading) {
                                // Background
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(Color.white.opacity(0.3))
                                
                                // Fill with emotion-specific color
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(colorForEmotion(emotion))
                                    .frame(width: barGeo.size.width * CGFloat(score / 100))
                            }
                        }
                        .frame(height: 8)
                        
                        Text(String(format: "%.0f%%", score))
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .foregroundColor(.white)
                            .frame(width: 35, alignment: .trailing)
                    }
                }
            }
            
            Divider()
                .background(Color.white.opacity(0.5))
                .padding(.vertical, 2)
            
            Text("Dominant: \(analysis.dominant.displayName)")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundColor(.yellow)
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.black.opacity(0.85))
                .shadow(color: .black.opacity(0.3), radius: 8)
        )
    }
    
    private func colorForEmotion(_ emotion: FEEmotion) -> Color {
        switch emotion {
        case .angry:
            return Color.red
        case .happy:
            return Color.yellow
        case .sad:
            return Color.blue
        case .fear:
            return Color.purple
        case .surprise:
            return Color.orange
        case .disgust:
            return Color.green
        case .neutral:
            return Color.gray
        }
    }
    
    private func visionRectToSwiftUI(_ bbox: CGRect, in size: CGSize) -> CGRect {
        // Vision coordinates: origin is bottom-left, normalized (0-1)
        // SwiftUI coordinates: origin is top-left, absolute pixels
        
        let w = bbox.width * size.width
        let h = bbox.height * size.height
        
        // X coordinate: Vision's x maps directly to SwiftUI's x (both left to right)
        let x = bbox.origin.x * size.width
        
        // Y coordinate: Vision's y starts from bottom, SwiftUI's y starts from top
        // So we need to flip: SwiftUI_y = height - (Vision_y + Vision_height) * height
        let y = (1.0 - bbox.origin.y - bbox.height) * size.height
        
        return CGRect(x: x, y: y, width: w, height: h)
    }
}

// MARK: - Preview
#if DEBUG
struct FaceExpressionDebugView_Previews: PreviewProvider {
    static var previews: some View {
        FaceExpressionDebugView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
#endif
