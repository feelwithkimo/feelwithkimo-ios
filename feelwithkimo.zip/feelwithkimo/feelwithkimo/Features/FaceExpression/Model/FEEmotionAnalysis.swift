//
//  FEEmotionAnalysis.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 05/11/25.
//

import Foundation
import CoreGraphics

public struct FEEmotionAnalysis: Identifiable {
    public let id = UUID()
    /// Vision-normalized rect (origin bottom-left, 0...1)
    public let region: CGRect
    /// Probability scores (0...100)
    public let scores: [FEEmotion: Double]
    public let dominant: FEEmotion
}
