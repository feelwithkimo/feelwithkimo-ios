//
//  FEEmotion.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 05/11/25.
//

import Foundation

public enum FEEmotion: String, CaseIterable, Identifiable {
    case angry, disgust, fear, happy, sad, surprise, neutral
    public var id: String { rawValue }
    var displayName: String { rawValue.capitalized }
}

public extension Dictionary where Key == FEEmotion, Value == Double {
    /// Returns the emotion with highest score, or nil if empty
    var dominantEmotion: FEEmotion? { self.max(by: { $0.value < $1.value })?.key }
}
