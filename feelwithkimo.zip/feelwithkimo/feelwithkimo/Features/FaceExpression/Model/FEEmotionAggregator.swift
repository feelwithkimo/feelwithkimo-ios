//
//  FEEmotionAggregator.swift
//  feelwithkimo
//
//  Created by Aristo Yongka on 06/11/25.
//

import Foundation

/// Aggregates emotion detections over time to smooth out results
final class FEEmotionAggregator {
    private var historyQueue: [FEEmotion] = []
    private let maxHistorySize = 10
    private let angryThreshold = 3 // Need 3 or more "angry" in last 10
    
    /// Add a new emotion detection to history
    func addDetection(_ dominant: FEEmotion) {
        historyQueue.append(dominant)
        
        // Keep only last 10
        if historyQueue.count > maxHistorySize {
            historyQueue.removeFirst()
        }
        
        print("📊 History (\(historyQueue.count)/\(maxHistorySize)): \(historyQueue.map { $0.rawValue })")
    }
    
    /// Check if user should be classified as "Angry" based on:
    /// 1. Current frame angry probability ≥ 10%, OR
    /// 2. At least 3 of last 10 detections were "angry"
    func isAngry(currentAngryProbability: Double) -> Bool {
        // Rule 1: Current frame is angry (≥10%)
        if currentAngryProbability >= 10.0 {
            print("✅ Angry: Current probability \(String(format: "%.1f", currentAngryProbability))% ≥ 10%")
            return true
        }
        
        // Rule 2: Aggregation - count angry in history
        let angryCount = historyQueue.filter { $0 == .angry }.count
        
        if angryCount >= angryThreshold {
            print("✅ Angry: \(angryCount)/\(historyQueue.count) recent detections were angry (threshold: \(angryThreshold))")
            return true
        }
        
        print("❌ Not Angry: probability=\(String(format: "%.1f", currentAngryProbability))%, history=\(angryCount)/\(historyQueue.count)")
        return false
    }
    
    /// Reset history (e.g., when face disappears)
    func reset() {
        historyQueue.removeAll()
        print("🔄 Aggregator history reset")
    }
    
    /// Get current history count
    var historyCount: Int {
        historyQueue.count
    }
}
