//
//  feelwithkimoApp.swift
//  feelwithkimo
//
//  Created by jonathan calvin sutrisna on 13/10/25.
//

import SwiftUI

@main
struct FeelwithkimoApp: App {
    var body: some Scene {
        WindowGroup {
          FaceExpressionView()
        }
    }
}
